'use client';

export default function ScrollingBanner() {
  return (
    <div className="bg-[#e1550d] text-white py-3 overflow-hidden relative rounded-t-lg">
      <div className="scroll-text whitespace-nowrap">
        <span className="inline-block px-8 font-bold text-sm tracking-wide">
          Buy $MIND of Pepe now // The best crypto presale for AI Agents // Huge early staking rewards // Buy $MIND of Pepe now // The best crypto presale for AI Agents // Huge early staking rewards // Buy $MIND of Pepe now // The best crypto presale for AI Agents // Huge early staking rewards // Buy $MIND of Pepe now // The best crypto presale for AI Agents // Huge early staking rewards //
        </span>
      </div>
    </div>
  );
}
